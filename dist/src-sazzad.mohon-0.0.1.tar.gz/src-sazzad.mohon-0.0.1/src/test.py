import sys
num = sys.argv[1]
for i in range(int(num)):
    print (i)